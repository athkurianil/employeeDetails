package com.anil.Service;

import java.util.List;

import com.anil.model.LoginPage;

public interface LoginPageService 
{
  public LoginPage save(LoginPage login);
  public LoginPage update(LoginPage login,int id);
  public void delete(int id);
  public LoginPage getOne(int id);
  public List<LoginPage> getAll();
}

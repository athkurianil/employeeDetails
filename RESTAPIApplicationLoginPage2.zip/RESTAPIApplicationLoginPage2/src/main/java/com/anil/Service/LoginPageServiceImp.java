package com.anil.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anil.Repo.LoginPageRepo;
import com.anil.model.LoginPage;

@Service
public class LoginPageServiceImp implements LoginPageService
{
	@Autowired
	private LoginPageRepo repo;

	@Override
	public LoginPage save(LoginPage login) 
	{
		LoginPage l=repo.save(login);
		return l;
	}

	@Override
	public LoginPage update(LoginPage login, int id)
	{
		LoginPage l=repo.findById(id).get();
		l.setUsername(login.getUsername());
		l.setPassword(login.getPassword());
		return repo.save(l);
	}

	@Override
	public void delete(int id)
	{
		repo.deleteById(id);

	}

	@Override
	public LoginPage getOne(int id)
	{
		LoginPage l=repo.findById(id).get();
		return l;
	}

	@Override
	public List<LoginPage> getAll()
	{
		 List<LoginPage>list=repo.findAll();
		return list;
	}

}

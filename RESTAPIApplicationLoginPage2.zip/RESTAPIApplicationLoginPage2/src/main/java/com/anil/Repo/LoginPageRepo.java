package com.anil.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anil.model.LoginPage;

@Repository
public interface LoginPageRepo extends JpaRepository<LoginPage, Integer> {

}

package com.anil.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.anil.Service.LoginPageService;
import com.anil.model.LoginPage;

@RestController
@CrossOrigin("*")
public class MyController 
{

	@Autowired
	private LoginPageService service;
	
	@PostMapping("save")
	public String save(@RequestBody LoginPage login)
	{
		LoginPage l=service.save(login);
		String message=null;
		if(l!=null)
		{
			message="Data Inserted Successfully";
		}
		else
		{
			message="Data Failed";
		}
		return message;
	}
	@PutMapping("update/{id}")
	public LoginPage update(@RequestBody LoginPage login,@PathVariable int id)
	{
		LoginPage l=service.update(login, id);
		return l;
	}
	@DeleteMapping("delete/{id}")
	public String delete(@PathVariable int id)
	{
		service.delete(id);
		String message="Record Deleted Successfully";
		return message;
	}
	@GetMapping("get/{id}")
	public LoginPage getOne(@PathVariable int id)
	{
		LoginPage l=service.getOne(id);
		return l;
	}
	@GetMapping("getAll")
	public List<LoginPage> getAll()
	{
		List<LoginPage> l=service.getAll();
		return l;
	}
	
}
